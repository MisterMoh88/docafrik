import ClientDashboard from '@/components/ClientDashboardBasic'

export default function DashboardPage() {
  return <ClientDashboard />
}