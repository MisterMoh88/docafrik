import ClientDashboard from '@/components/ClientDashboardBasic'

export default function ClientPage() {
  return <ClientDashboard />
}